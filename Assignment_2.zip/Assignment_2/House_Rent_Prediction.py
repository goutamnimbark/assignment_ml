#!/usr/bin/env python
# coding: utf-8

# In[3]:


import pandas as pd 
import numpy as np
from sklearn import linear_model
import matplotlib.pyplot as plt


# In[4]:


df=pd.read_excel("D:\Ml Project\House_Rent.xlsx")
df


# In[5]:


get_ipython().run_line_magic('matplotlib', 'inline')
plt.xlabel('Area')
plt.ylabel('Price')
plt.scatter(df.Area,df.Price,color='red',marker='+')


# In[6]:


new_df = df.drop('Price',axis='columns')
new_df


# In[7]:


model=linear_model.LinearRegression()
model.fit(new_df,df.Price)


# In[8]:


model.predict([[3300]])
model.predict([[3300]])


# In[9]:


model.predict([[4000]])


# In[10]:


get_ipython().run_line_magic('matplotlib', 'inline')
plt.xlabel('Area')
plt.ylabel('Price')
plt.scatter(df.Area,df.Price,color='red',marker='+')


# In[ ]:




