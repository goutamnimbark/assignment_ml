#!/usr/bin/env python
# coding: utf-8

# In[2]:


import pandas as pd
import numpy as np
from sklearn import linear_model


# In[4]:


df=pd.read_csv("D:\Ml Project\homeprices.csv")
df


# In[6]:


import math
df.bedrooms.median()


# In[9]:


df.bedrooms=df.bedrooms.fillna(df.bedrooms.median())


# In[10]:


df


# In[13]:


model=linear_model.LinearRegression()
model.fit(df.drop('price',axis='columns'),df.price)


# In[14]:


model.predict([[3000,5.0,50]])


# In[ ]:




